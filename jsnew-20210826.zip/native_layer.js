
function getParser(url) {
    var parserDef =  JSON.stringify(RootFunction(url));
    console.log("getParser: "+parserDef)
    return parserDef;
}

function getParseResult(methodName, url) {
    console.log("methodName: "+methodName + ", url: " + url);
    var fn = window[methodName];
    var rs = JSON.stringify(fn(url));
    console.log("getParseResult: "+rs);
    return rs;
}

function getStringBtween(str,str1,str2){
	var a = str.substring(str.indexOf(str1)+str1.length);
	a = a.substring(0, a.indexOf(str2));
	return a;
}

function getMD5(str) {
    return client.getMD5(str);
}

function writeFileWithName(fileContent, fileName) {
    return client.writeFile(fileContent, fileName);
}

function getRegex(attributes, pattern) {
    // new RegExp(pattern, attributes);
    var result = attributes.match(pattern);
    console.log("getRegex: " + result);
    return result;
}

function log(content) {
	console.log(content);
}

function AESDecrypt128(content, key) {
    return client.AESDecrypt128(content, key);
}

function encC20Ep(content, key) {
    return client.encC20Ep(content, key);
}

function urlRequest(url) {
    return urlRequestWithPara(url, "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36", "User-Agent");
}

function getUrlContent(url) {
    var header = "{}"
    var content = client.getUrlContent(url, header);
    return content;
}

function urlRequestWithPara(url, headerVal, headerKey) {
    var header = "{'"+headerKey+"':'"+headerVal+"'}";
    var content = client.getUrlContent(url, header);
    return content;
}

function urlRequestWithHeader(url, header) {
    var content = client.getUrlContentWithHeader(url, header);
    return content;
}

//form
function getPostContent(url,post,header) {
    var content = client.getPostContent(url, post, header);
    return content;
}


function getPostContent1(url,post,header,mediaType) {
    var content = client.getPostContent1(url, post, header,mediaType);
    return content;
}

function getJxtvKey(publicKey) {
    var content = client.getJxtvKey(publicKey);
    return content;
}

function getLocation(url) {
    var content = client.getLocation(url);
    return content;
}

function urlRequestWithParaAndCoding(url, arr, encode) {
    var header = "{}"
    for (i=0; i<arr.length; i++) {
        header[arr[i].header] = arr[i].value;
    }
    var content = client.getUrlContent(url, header);
    return content;
}

function getBstFk(c, key) {
    var content = client.getBstFk(c, key);
    return content;
}

function getNwtime() {
	if(typeof client.getNwtime!='undefined'){
		var content = client.getNwtime();
	}else{
		var content = (Date.parse(new Date()))/1000;
	}
    return content;
}

function getPkgName() {
	if(typeof client.getPkgName!='undefined'){
		var content = client.getPkgName();
	}else{
		var content = "com.jykds.default";
	}
    return content;
}

function getAppVersion() {
	if(typeof client.getAppVersion!='undefined'){
		var content = client.getAppVersion();
	}else{
		var content = "1.0.0";
	}
    return content;
}

function getImei() {
	if(typeof client.getImei!='undefined'){
		var content = client.getImei();
	}else{
		var content = "555555555555555";
	}
    return content;
}

function getMac() {
	if(typeof client.getMac!='undefined'){
		var content = client.getMac();
	}else{
		var content = "00:91:91:91:55";
	}
	if(content=="undefined" || content==""){
		content = "00:91:91:91:55";
	}
    return content;
}

function getRespAndHeaders(url,headers) {
	if(typeof client.getRespAndHeaders!='undefined'){
		var content = client.getRespAndHeaders(url,headers);
	}else{
		var content = "undefined";
	}
    return content;
}

function getHncscsKey(){
	if(typeof client.getHncscsKey!='undefined'){
		var content = client.getHncscsKey();
	}else{
		var content = "undefined";
	}
    return content;
}

function getHost(){
	var app = getPkgName();
	var host = "47.104.173.199";
	return host;
}